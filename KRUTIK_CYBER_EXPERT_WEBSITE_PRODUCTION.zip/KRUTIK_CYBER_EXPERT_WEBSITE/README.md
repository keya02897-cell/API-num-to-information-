# KRUTIK CYBER EXPERT API Website

Production-oriented Flask website for the existing KRUTIK CYBER EXPERT API key/access system.

## Features
- User registration/login
- Basic / Pro / Custom plans
- Access requests
- Owner approve/reject
- One-time display of newly generated API key
- User dashboard, key status, usage and logs
- Owner dashboard
- User block/unblock and API enable/disable
- API global ON/OFF
- Plan/settings editor
- Existing SQLite database integration
- API documentation page
- Secure password hashing and session cookies
- Render/Gunicorn ready

## Environment
Set:
- `DB_PATH=bot.db`
- `OWNER_CHAT_ID=<your Telegram numeric user ID>`
- `WEB_SECRET=<long random secret>`
- `OWNER_WEB_SECRET=<separate strong owner-panel secret>`

## Run locally
```bash
pip install -r requirements.txt
python website.py
```
Open `http://127.0.0.1:10000`

## Render
Build command:
```bash
pip install -r requirements.txt
```
Start command:
```bash
gunicorn -w 2 -b 0.0.0.0:$PORT website:app
```

Important: SQLite on Render's ephemeral filesystem is not durable across service replacement/redeploy. For production persistence, attach a persistent disk or move the DB to PostgreSQL.

### Optional Telegram notifications
If the original Telegram bot is still running, set `BOT_TOKEN` to let the website notify the owner about new requests and send approved keys to real Telegram users.
